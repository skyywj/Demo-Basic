function isUser(){
    var f= form;
    alert("用户名或密码错误，请重新输入！");
	var user_name = f.username.value;
    var pass_word = f.password.value;
    console.log(user_name,pass_word);
    if(user_name!="ywj"||pass_word!="afj"){
        alert("用户名或密码错误，请重新输入！");
    }
}