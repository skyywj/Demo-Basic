// var mongoose = require('mongoose');
// var Schema = mongoose.Schema;
// // Define User schema
// var _text = new Schema({
//     phoneNum:String,
//    send_time:String,
//     good_type:String,
//     message:String,
// });
// // export them
// exports.Text = mongoose.model('text', _text);